#include<iostream>
#include<stack>
#include<string>
using namespace std;
int main(){
    int cases;
    cin >> cases;
    cin.get();
    while(cases--){
        string s;
        bool tf = true;
        getline(cin, s);
        stack<char> stack_;
        while(!stack_.empty()){
            stack_.pop();
        }
        for(int i = 0; i< s.length(); i++){
            cout << s[i] << endl;
            if(s[i] =='(' || s[i] == '['){
                stack_.push(s[i]);
            }
            else if(s[i] ==')' || s[i] == ']'){
                if(!stack_.empty() && stack_.top() == '(' && s[i] == ')'){
                    stack_.pop();
                }
                else if(!stack_.empty() && stack_.top() == '[' && s[i] == ']'){
                    stack_.pop();
                }
                else{
                    tf = false;
                    break;
                }
            }
        }
        if(stack_.empty() && tf){
            cout << "Yes" << endl;
        }
        else{
            cout << "No" << endl;
        }
    }
}
